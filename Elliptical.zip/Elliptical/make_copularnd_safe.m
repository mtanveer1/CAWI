function R = make_copularnd_safe(R, d_expected)
% Make R a valid SPD correlation matrix for copularnd.
% - size check
% - real, symmetric
% - normalize to correlation (unit diag)
% - clip off-diagonals
% - enforce SPD via cholcov + identity mixing
% - final validation

if nargin < 2
    d_expected = size(R,1);
end

% Size & type checks
if isempty(R) || ~ismatrix(R) || size(R,1) ~= size(R,2) || size(R,1) ~= d_expected
    R = eye(d_expected);
    return
end
R = double(real(R));

% Clean & symmetrize
R(~isfinite(R)) = 0;
R = (R + R.')/2;

% Normalize to correlation (unit diag)
d = size(R,1);
s = sqrt(abs(diag(R)));  s(s==0) = 1;
S = diag(1./s);
R = S * R * S;
R(1:d+1:end) = 1;

% Clip off-diagonals strictly inside (-1,1)
R = min(max(R, -0.999), 0.999);

% Enforce SPD via cholcov; if fails, mix with identity until it passes
mix = 0;
ok = false;
for iter = 1:8
    Rtest = (1-mix)*R + mix*eye(d);
    try
        cholcov(Rtest,0);      % throws if not PSD/SPD
        ok = true;
        R = Rtest;
        break
    catch
        % increase mixing gradually
        if mix == 0
            mix = 1e-8;
        else
            mix = mix * 10;
        end
        if mix > 1e-1   % last resort
            break
        end
    end
end

% If still not OK, fall back to identity correlation
if ~ok
    R = eye(d);
end

% Renormalize (numerical drift) and final clip
R = (R + R.')/2;
R(1:d+1:end) = 1;
R = min(max(R, -0.999), 0.999);

% Final sanity: try a 1-sample call; if it fails, use identity
try
    ~isempty(copularnd('Gaussian', R, 1)); 
catch
    R = eye(d);
end
end
