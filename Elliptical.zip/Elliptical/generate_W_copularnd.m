function W = generate_W_copularnd(method, copula_params, Nfea, N)
% COPULARND-based weight generator (Baseline / Gaussian / t)
% Uses make_copularnd_safe to ensure R is valid before calling copularnd.

switch lower(method)
    case 'baseline'
        U = rand(N, Nfea);                 % N x d uniforms
        U = bound_open01(U);
        W = (U' * 2) - 1;                  % d x N

    case 'gaussian'
        R = make_copularnd_safe(copula_params.Rho, Nfea);
        U = copularnd('Gaussian', R, N);   % N x d
        U = bound_open01(U);
        W = (U' * 2) - 1;

    case 't'
        R  = make_copularnd_safe(copula_params.Rho, Nfea);
        nu = max(2, min(50, copula_params.nu));
        U  = copularnd('t', R, nu, N);     % N x d
        U  = bound_open01(U);
        W  = (U' * 2) - 1;

    otherwise
        error('generate_W_copularnd: method must be Baseline/Gaussian/t.');
end
end

function U = bound_open01(U)
epsi = 1e-12;
U = max(min(U, 1 - epsi), epsi);
end
