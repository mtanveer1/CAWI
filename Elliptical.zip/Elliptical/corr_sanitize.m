function R = corr_sanitize(R, d_expected)
% Make R a valid correlation matrix: symmetric, finite, unit diag, PD.
% If size mismatch, return identity of expected size.

if nargin < 2
    d_expected = size(R,1);
end

% Size & type checks
if isempty(R) || ~ismatrix(R) || size(R,1)~=size(R,2) || size(R,1)~=d_expected
    R = eye(d_expected);
    return
end

% Replace NaN/Inf and symmetrize
R(~isfinite(R)) = 0;
R = (R + R')/2;

% Clip entries to [-0.999, 0.999]
R = min(max(R, -0.999), 0.999);

% Project to SPD via eigenvalue clipping
[V,D] = eig((R+R')/2);
e = diag(D);
e(e < 1e-8) = 1e-8;
R = V*diag(e)*V';

% Force exact unit diagonal and final clip
R(1:size(R,1)+1:end) = 1;
R = min(max(R, -0.999), 0.999);
end
