function U = sample_t_copula_safe(R, nu, n)
% Robust t copula sampling (equivalent to copularnd('t',...)):
% 1) Ensure R is valid correlation.
% 2) Draw X ~ N(0, R) via Cholesky with adaptive jitter.
% 3) Scale by sqrt(G/nu), G ~ chi2_nu, then U = tcdf(T, nu).

d = size(R,1);
R = corr_sanitize(R, d);

eps0 = 1e-10;
for tries = 1:8
    try
        L = chol(R + eps0*eye(d), 'lower');
        break
    catch
        eps0 = eps0 * 10;
        if tries == 8
            L = chol(eye(d), 'lower');
            warning('sample_t_copula_safe: fell back to identity correlation.');
        end
    end
end

X = randn(n, d) * L.';        % n x d ~ N(0, R)
G = chi2rnd(nu, n, 1) / nu;   % n x 1
T = X ./ sqrt(G);             % broadcast scale
U = tcdf(T, nu);              % n x d in (0,1)
end
