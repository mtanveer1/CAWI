function hp_list = copula_hp_grid(method, base_params)
% Build a small, standard HP grid around the base copula fit.
% Keeps your fitting unchanged; we only try mild variants.

switch lower(method)
    case 'gaussian'
        % Shrinkage of correlation to improve PD/robustness
        lambdas = [0, 0.1, 0.25, 0.5];
        R = base_params.Rho;
        d = size(R,1); I = eye(d);
        hp_list = repmat(struct('family','Gaussian','Rho',[]), numel(lambdas), 1);
        for i = 1:numel(lambdas)
            lam = lambdas(i);
            Rsh = (1 - lam)*R + lam*I;
            hp_list(i).Rho = corr_sanitize(Rsh);
        end

    case 't'
        % Tune nu a bit around the base; also allow mild shrinkage
        R = base_params.Rho;
        d = size(R,1); I = eye(d);
        lambdas = [0, 0.1, 0.25];
        nu0 = max(2, min(50, base_params.nu));
        nu_cand = unique([nu0, 4, 6, 8, 10, 16, 30]);
        hp_list = repmat(struct('family','t','Rho',[],'nu',[]), numel(lambdas)*numel(nu_cand), 1);
        idx = 1;
        for i = 1:numel(lambdas)
            Rsh = (1 - lambdas(i))*R + lambdas(i)*I;
            Rsh = corr_sanitize(Rsh);
            for j = 1:numel(nu_cand)
                hp_list(idx).Rho = Rsh;
                hp_list(idx).nu  = nu_cand(j);
                idx = idx + 1;
            end
        end

    otherwise
        error('copula_hp_grid: method must be Gaussian or t here.');
end
end
