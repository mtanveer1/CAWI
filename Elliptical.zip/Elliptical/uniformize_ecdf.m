function U = uniformize_ecdf(X)
% ECDF + linear interp + tiny noise + clamp to (0,1) 
[n, d] = size(X);
U = zeros(n,d);
for j = 1:d
    [f, x] = ecdf(X(:, j));
    x = x + randn(size(x)) * 1e-6;                  % avoid ties
    U(:, j) = interp1(x, f, X(:, j), 'linear', 'extrap');
end
epsi = 1e-10;
U = max(min(U, 1 - epsi), epsi);
end
