function U = sample_gaussian_copula_safe(R, n)
% Robust Gaussian copula sampling:
% 1) Ensure R is a valid correlation (sym, PD-ish, diag=1).
% 2) Draw Z ~ N(0, R) via Cholesky with adaptive jitter.
% 3) U = Phi(Z).

d = size(R,1);
R = corr_sanitize(R, d);

eps0 = 1e-10;
for tries = 1:8
    try
        L = chol(R + eps0*eye(d), 'lower');   % force PD if needed
        break
    catch
        eps0 = eps0 * 10;
        if tries == 8
            L = chol(eye(d), 'lower');
            warning('sample_gaussian_copula_safe: fell back to identity correlation.');
        end
    end
end

Z = randn(n, d) * L.';   % n x d ~ N(0, R)
U = normcdf(Z);          % map to (0,1)
end
