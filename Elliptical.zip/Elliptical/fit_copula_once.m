function params = fit_copula_once(method, U)
% EXACT copula fitting like your t-copula code (Elliptical only).
% U: n x d uniforms from ECDF.
switch lower(method)
    case 'gaussian'
        Rho = copulafit('Gaussian', U);                           % base
        params = struct('family','Gaussian','Rho',Rho);
    case 't'
        [Rho, nu] = copulafit('t', U, 'Method','ApproximateML');  % base
        nu = max(2, min(50, nu));                                 % guardrail only
        params = struct('family','t','Rho',Rho,'nu',nu);
    otherwise
        error('fit_copula_once: method must be Gaussian or t here.');
end
end
