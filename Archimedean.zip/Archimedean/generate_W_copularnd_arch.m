function W = generate_W_copularnd_arch(method, copula_params, Nfea, N)
% Returns W of size (Nfea × N). Uses inbuilt copularnd first; if the
% MATLAB version only supports bivariate, falls back to Marshall–Olkin.
fam = lower(method);
theta = copula_params.theta;

% Prefer inbuilt (multi-d if available)
try
    U = copularnd(capfirst(fam), theta, N, Nfea);
    if size(U,2) ~= Nfea
        error('bivariate-only returned');
    end
catch
    % Fallback: robust Marshall–Olkin generator
    U = arch_mo_draw(fam, theta, N, Nfea);
end

U = max(min(U, 1 - 1e-12), 1e-12);
W = (2*U - 1).';  % Nfea x N
end

function s = capfirst(s0), s = s0; s(1) = upper(s(1)); end
