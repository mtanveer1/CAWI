function main_run_rvfl_arch_pairfit()
% Evaluate ARCHIMEDEAN copulas (Clayton, Frank, Gumbel) with RVFL.
% Pairwise bivariate fitting via copulafit, aggregate θ per fold (median),
% then tune θ by small multiplicative scales. Sampling via copularnd.

%% ========= CONFIG =========
data_dir    = 'path/to/your/dataset/folder';    % Provide the folder path containing the datasets (.mat/.txt)
result_root = 'path/to/save/results';           % Specify where to save output results


methods = {'Clayton','Frank','Gumbel'};

activation_grid = 1:1:7;                 % 1=selu,2=relu,3=sigmoid,4=sin,5=tribas,6=radbas,7=tansig
C_grid          = 10.^(-6:1:6);
N_grid          = (3:20:203);
no_part         = 5;

rng(42,'twister');

%% ========= I/O prep =========
files = [dir(fullfile(data_dir,'*.mat')); dir(fullfile(data_dir,'*.txt'))];
assert(~isempty(files), 'No .mat or .txt files found in %s', data_dir);

for m = 1:numel(methods)
    mdir = fullfile(result_root, methods{m});
    ensure_dir(mdir);
    outf = fullfile(mdir, 'Results.txt');
    if ~isfile(outf)
        fid = fopen(outf,'w');
        fprintf(fid, "DataSetName\t BestMeanTrainAccuracy\t BestStdTrainAccuracy\t BestMeanTestAccuracy\t BestStdTestAccuracy\t BestMeanTrainTime\t BestStdTrainTime\t BestMeanTestTime\t BestStdTestTime\t Best_C\t Best_N\t Best_activation\n");
        fclose(fid);
    end
end

%% ========= Loop over datasets =========
for u = 1:numel(files)
    data_path = fullfile(data_dir, files(u).name);
    All_data  = read_numeric_matrix(data_path);

    % Map -1 -> 0 (your rule)
    [m,n] = size(All_data);
    for i = 1:m
        if All_data(i,n) == -1, All_data(i,n) = 0; end
    end

    % Feature cleanup -> zscore
    X_raw = All_data(:,1:end-1);
    y_raw = All_data(:,end);
    [X_clean, feat_info] = remove_constant_and_duplicate_columns(X_raw);
    fprintf('Dataset %s | removed %d constant, %d duplicate (kept %d/%d)\n', ...
        files(u).name, numel(feat_info.const_idx), numel(feat_info.dup_idx), size(X_clean,2), size(X_raw,2));
    assert(size(X_clean,2) >= 1, 'No features left after cleanup.');

    All_X_data = zscore(X_clean')';
    All_Y_data = y_raw;
    All_data   = [All_X_data, All_Y_data];

    class_labels = unique(All_Y_data(:))';

    length_total = size(All_data,1);
    block_size   = length_total/(no_part*1.0);

    %% ----- per-method grid over folds -----
    for mth = 1:numel(methods)
        method = methods{mth};
        fprintf('Dataset: %s | Method: %s\n', files(u).name, method);

        % Fit-once-per-fold θ via pairwise copulafit, then build θ grid
        copula_hp_lists = cell(no_part,1);
        for part = 1:no_part
            [trainX, ~, ~, ~] = get_fold_split(All_data, part, block_size, length_total);
            Utr = uniformize_ecdf(trainX);
            base_params = fit_arch_pairwise_copulafit(method, Utr);     % uses copulafit per pair
            copula_hp_lists{part} = arch_copula_hp_grid(method, base_params);
        end

        BestMeanTestAccuracy = -inf;
        BestMeanTrainAccuracy = NaN; BestStdTrainAccuracy = NaN;
        BestStdTestAccuracy   = NaN;
        BestMeanTrainTime     = NaN; BestStdTrainTime     = NaN;
        BestMeanTestTime      = NaN; BestStdTestTime      = NaN;
        best = struct('C',NaN,'N',NaN,'activation',NaN);

        num_hp = numel(copula_hp_lists{1});

        for hpc = 1:num_hp
            for ii = 1:numel(C_grid)
                option.C = C_grid(ii);
                for jj = 1:numel(N_grid)
                    option.N = N_grid(jj);
                    for kk = 1:numel(activation_grid)
                        option.activation = activation_grid(kk);

                        foldTrainAcc  = zeros(no_part,1);
                        foldTestAcc   = zeros(no_part,1);
                        foldTrainTime = zeros(no_part,1);
                        foldTestTime  = zeros(no_part,1);

                        for part = 1:no_part
                            [trainX, trainY, testX, testY] = get_fold_split(All_data, part, block_size, length_total);
                            params = copula_hp_lists{part}(hpc);

                            [tra, tea, trt, tet] = rvfl_train_eval_generic_arch( ...
                                trainX, trainY, testX, testY, option, method, params, class_labels);

                            foldTrainAcc(part)  = tra;
                            foldTestAcc(part)   = tea;
                            foldTrainTime(part) = trt;
                            foldTestTime(part)  = tet;
                        end

                        meanTrain = mean(foldTrainAcc);  stdTrain = std(foldTrainAcc);
                        meanTest  = mean(foldTestAcc);   stdTest  = std(foldTestAcc);
                        meanTTr   = mean(foldTrainTime); stdTTr   = std(foldTrainTime);
                        meanTTe   = mean(foldTestTime);  stdTTe   = std(foldTestTime);

                        if meanTest > BestMeanTestAccuracy
                            BestMeanTestAccuracy = meanTest;  BestStdTestAccuracy  = stdTest;
                            BestMeanTrainAccuracy= meanTrain; BestStdTrainAccuracy = stdTrain;
                            BestMeanTrainTime    = meanTTr;   BestStdTrainTime     = stdTTr;
                            BestMeanTestTime     = meanTTe;   BestStdTestTime      = stdTTe;
                            best.C = option.C; best.N = option.N; best.activation = option.activation;
                            if BestMeanTestAccuracy == 100, break; end
                        end
                    end
                    if BestMeanTestAccuracy == 100, break; end
                end
                if BestMeanTestAccuracy == 100, break; end
            end
            if BestMeanTestAccuracy == 100, break; end
        end

        % Write one row per (dataset × method)
        mdir = fullfile(result_root, method);
        outf = fullfile(mdir, 'Results.txt');
        fid = fopen(outf,'a');
        fprintf(fid, "%s\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.6f\t %d\t %d\n", ...
            files(u).name, ...
            BestMeanTrainAccuracy, BestStdTrainAccuracy, ...
            BestMeanTestAccuracy,  BestStdTestAccuracy, ...
            BestMeanTrainTime,     BestStdTrainTime, ...
            BestMeanTestTime,      BestStdTestTime, ...
            best.C, best.N, best.activation);
        fclose(fid);
    end
end

fprintf('Done.\n');
end

%% ---- local helpers ----
function [trainX, trainY, testX, testY] = get_fold_split(All_data, part, block_size, length_total)
t_1 = ceil((part-1)*block_size);
t_2 = ceil(part*block_size);
DataTest  = All_data(t_1+1:t_2,:);
DataTrain = [All_data(1:t_1,:); All_data(t_2+1:length_total,:)];
trainX = DataTrain(:,1:end-1);
trainY = DataTrain(:,end);
testX  = DataTest(:,1:end-1);
testY  = DataTest(:,end);
end
