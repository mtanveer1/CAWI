function [train_accuracy, test_accuracy, train_time, test_time] = rvfl_train_eval_generic_arch( ...
        trainX, trainY, testX, testY, option, method, copula_params, class_labels)

N = option.N; C = option.C; s = 1; activation = option.activation;
[Nsample, Nfea] = size(trainX);

% one-hot targets (multiclass ok)
K = numel(class_labels);
Ytr = zeros(numel(trainY), K);
for k = 1:K, Ytr(:,k) = (trainY == class_labels(k)); end

%% TRAIN
tic;
W = generate_W_copularnd_arch(method, copula_params, Nfea, N);   % Arch families

% Ensure W shape
if size(W,1) ~= Nfea && size(W,2) == Nfea, W = W.'; end
assert(size(W,1) == Nfea && size(W,2) == N, ...
    'W dimension mismatch: expected %d x %d, got %d x %d.', Nfea, N, size(W,1), size(W,2));

b = s * rand(1, N);
X1 = trainX * W + repmat(b, Nsample, 1);
X1 = apply_activation(X1, activation);
X  = [trainX, X1];
X  = [X, ones(Nsample, 1)];

if size(X, 2) < Nsample
    beta = (eye(size(X, 2)) * (1 / C) + X' * X) \ (X' * Ytr);
else
    beta = X' * ((eye(size(X, 1)) * (1 / C) + X * X') \ Ytr);
end

train_logits = X * beta;
train_time   = toc;

train_probs = softmax_rows(train_logits);
[~, pred_train] = max(train_probs, [], 2);
[~, true_train] = max(Ytr, [], 2);
train_accuracy  = mean(pred_train == true_train) * 100;

%% TEST
tic;
Nsample_te = size(testX,1);
Yte = zeros(numel(testY), K);
for k = 1:K, Yte(:,k) = (testY == class_labels(k)); end

X1_te = testX * W + repmat(b, Nsample_te, 1);
X1_te = apply_activation(X1_te, activation);
X1_te = [X1_te, ones(Nsample_te, 1)];
X_te  = [testX, X1_te];

test_logits = X_te * beta;
test_time   = toc;

test_probs = softmax_rows(test_logits);
[~, pred_test] = max(test_probs, [], 2);
[~, true_test] = max(Yte, [], 2);
test_accuracy  = mean(pred_test == true_test) * 100;
end
