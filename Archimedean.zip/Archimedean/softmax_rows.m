function P = softmax_rows(Z)
Zs = bsxfun(@minus, Z, max(Z,[],2));
num = exp(Zs); den = sum(num,2);
P = bsxfun(@rdivide, num, den);
end
