function U = arch_mo_draw(fam, theta, n, d)
fam = lower(fam);
switch fam
    case 'clayton'  % theta>0
        theta = max(theta, 1e-3);
        V = gamrnd(1/theta, 1, n, 1);      % Gamma(shape=1/θ, scale=1)
        E = exprnd(1, n, d);               % Exp(1)
        U = (1 + E ./ V) .^ (-1/theta);

    case 'frank'    % theta ≠ 0
        if abs(theta) < 1e-6, theta = sign(theta + (theta==0))*1e-3; end
        p = 1 - exp(-theta);
        p = min(max(p, 1e-12), 1-1e-12);
        K = logseries_rnd_LS(p, n);        % n×1
        E = exprnd(1, n, d);
        U = -(1/theta) * log( 1 - (1 - exp(-theta)) .* exp(-E ./ K) );

    case 'gumbel'   % theta ≥ 1
        theta = max(theta, 1.0001);
        alpha = 1/theta;                    % 0<alpha≤1
        V = positive_stable_rnd(alpha, n);
        V = max(V, realmin);
        E = exprnd(1, n, d);
        U = exp( - (E ./ V) .^ alpha );

    otherwise
        error('arch_mo_draw: unknown family %s', fam);
end
U = min(max(U, eps), 1 - eps);
end

function K = logseries_rnd_LS(p, n)
a = -1 / log(1 - p);
K = zeros(n,1);
for i = 1:n
    u = rand;
    s = 0; k = 1; pk = p;
    while true
        s = s + a * pk / k;
        if u <= s, K(i) = k; break; end
        k  = k + 1; pk = pk * p;
        if k > 1e6, K(i) = k; break; end
    end
end
end

function V = positive_stable_rnd(alpha, n)
U = pi * rand(n,1);
W = exprnd(1, n,1);
sU   = sin(U);
num1 = sin(alpha * U);
num2 = sin((1 - alpha) * U);
V = (num1 ./ (sU .^ alpha)) .* ((num2 ./ W) .^ ((1 - alpha)/alpha));
V = max(V, realmin);
end
