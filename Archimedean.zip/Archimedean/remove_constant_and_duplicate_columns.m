function [X_out, info] = remove_constant_and_duplicate_columns(X_in)
[n, d] = size(X_in);
const_mask = (max(X_in,[],1) - min(X_in,[],1) == 0);
const_idx  = find(const_mask);
X1         = X_in(:, ~const_mask);

if isempty(X1)
    X_out = X1;
    info = struct('const_idx', const_idx, 'dup_idx', [], 'kept_idx', []);
    return;
end

[X1T_unique, ia] = unique(X1','rows','stable'); %#ok<ASGLU>
keep_mask = false(1, size(X1,2)); keep_mask(ia) = true;

dup_rel_idx = find(~keep_mask);
X_out       = X1(:, keep_mask);

orig_keep_mask = ~const_mask;
orig_idx = find(orig_keep_mask);
dup_idx  = orig_idx(dup_rel_idx);
kept_idx = orig_idx(keep_mask);

info = struct('const_idx', const_idx, 'dup_idx', dup_idx, 'kept_idx', kept_idx);
if ~isnumeric(X_out) || isempty(X_out) || ~all(isfinite(X_out(:)))
    error('remove_constant_and_duplicate_columns: result invalid or empty.');
end
end
