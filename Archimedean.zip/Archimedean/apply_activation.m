function X = apply_activation(X, activation)
switch activation
    case 1, X = selu(X);
    case 2, X = relu(X);
    case 3, X = sigmoid(X);
    case 4, X = sin(X);
    case 5, X = tribas_fn(X);
    case 6, X = radbas_fn(X);
    case 7, X = tansig_fn(X);
    otherwise, error('Unknown activation code: %d', activation);
end

function Y = selu(Z)
alpha = 1.6732632423543772; lambda = 1.0507009873554805;
Y = lambda * ( (Z>0).*Z + (Z<=0).*(alpha.*(exp(Z)-1)) );
end
function Y = relu(Z),     Y = max(Z,0); end
function Y = sigmoid(Z),  Y = 1 ./ (1 + exp(-Z)); end
function Y = tribas_fn(Z),Y = max(0, 1 - abs(Z)); end
function Y = radbas_fn(Z),Y = exp(-(Z.^2)); end
function Y = tansig_fn(Z),Y = 2 ./ (1 + exp(-2*Z)) - 1; end
end
