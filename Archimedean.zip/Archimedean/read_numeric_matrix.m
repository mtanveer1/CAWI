function M = read_numeric_matrix(fp)
[~,~,ext] = fileparts(fp);
switch lower(ext)
    case '.mat'
        S = load(fp);
        fn = fieldnames(S);
        M = [];
        for k = 1:numel(fn)
            val = S.(fn{k});
            if isnumeric(val) && ismatrix(val)
                M = val; break;
            end
        end
        if isempty(M)
            tmp = importdata(fp);
            if isstruct(tmp) && isfield(tmp,'data'), M = tmp.data; else, M = tmp; end
        end
    otherwise  % .txt etc.
        try
            M = readmatrix(fp);   % auto detects delimiter/header
        catch
            tmp = importdata(fp);
            if isstruct(tmp) && isfield(tmp,'data'), M = tmp.data; else, M = tmp; end
        end
end
if ~isnumeric(M) || isempty(M)
    error('read_numeric_matrix: could not read a numeric matrix from %s', fp);
end
end
