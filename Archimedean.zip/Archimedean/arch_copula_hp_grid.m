function hp_list = arch_copula_hp_grid(family, base_params)
% Small multiplicative scales around θ0 from pairwise copulafit aggregation.
scales = [0.75, 0.85, 1.00, 1.15, 1.30];

fam = lower(family);
theta0 = base_params.theta;

switch fam
    case 'clayton'
        hp_list = repmat(struct('family','Clayton','theta',[]), numel(scales), 1);
        for i=1:numel(scales), hp_list(i).theta = max(1e-3, theta0*scales(i)); end
    case 'frank'
        hp_list = repmat(struct('family','Frank','theta',[]), numel(scales), 1);
        for i=1:numel(scales), hp_list(i).theta = theta0*scales(i); end
    case 'gumbel'
        hp_list = repmat(struct('family','Gumbel','theta',[]), numel(scales), 1);
        for i=1:numel(scales), hp_list(i).theta = max(1.0001, theta0*scales(i)); end
    otherwise
        error('arch_copula_hp_grid: unsupported family %s', family);
end
end
