function params = fit_arch_pairwise_copulafit(family, U)
% Pairwise bivariate copulafit for (i,j), i<j, then aggregate to one θ (median).
% U is n x d uniforms from ECDF.
fam = lower(family);
[~, d] = size(U);
thetas = nan(d,d);

for i = 1:d
    for j = (i+1):d
        try
            th = copulafit(capfirst(fam), U(:,[i j]));
            thetas(i,j) = th;
        catch
            % if pair fitting fails (e.g., degenerate), leave as NaN
        end
    end
end

theta_vec = thetas(triu(true(d),1));
theta_vec = theta_vec(isfinite(theta_vec));

% If nothing valid, fallback from Kendall's tau median (robust)
if isempty(theta_vec)
    K = corr(U, 'type','Kendall','rows','pairwise');
    tau_med = median(K(triu(true(d),1)), 'omitnan');
    if ~isfinite(tau_med), tau_med = 0; end
    switch fam
        case 'clayton', theta0 = max(1e-3, 2*tau_med/(1 - tau_med));
        case 'gumbel',  theta0 = max(1.0001, 1/(1 - max(0,tau_med)));
        case 'frank'
            if abs(tau_med) < 1e-8, theta0 = 1e-3;
            else, theta0 = frank_theta_from_tau(tau_med);
            end
        otherwise, error('Unknown family %s', family);
    end
else
    theta0 = median(theta_vec,'omitnan');   % aggregate pairwise fits
end

% Clamp to valid domain
switch fam
    case 'clayton', theta0 = max(theta0, 1e-3);
    case 'gumbel',  theta0 = max(theta0, 1.0001);
    case 'frank'
        if abs(theta0) < 1e-6, theta0 = sign(theta0 + (theta0==0))*1e-3; end
end

params = struct('family',capfirst(fam),'theta',theta0);
end

function s = capfirst(s0), s = s0; s(1) = upper(s(1)); end

function theta = frank_theta_from_tau(tau_target)
% invert Kendall's tau for Frank via copulastat in a root-finder
if tau_target > 0, a=1e-3; b=50;
elseif tau_target < 0, a=-50; b=-1e-3;
else, theta=1e-3; return; end
fa = frank_tau(a) - tau_target; fb = frank_tau(b) - tau_target;
if ~(isfinite(fa) && isfinite(fb)) || fa*fb > 0, theta = sign(tau_target)*1e-3; return; end
theta = fzero(@(th) frank_tau(th)-tau_target, [a b]);
    function t = frank_tau(th), [t,~] = copulastat('Frank', th); end
end
